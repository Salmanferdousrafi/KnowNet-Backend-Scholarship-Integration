"""
Initialize database: create all tables.
"""
from app.db.session import engine, Base
from app.models import user, project, knowledge, scholarship, refresh_token

def init_db():
    Base.metadata.create_all(bind=engine)
