from app.schemas.user import *
from app.schemas.auth import *
from app.schemas.project import *
from app.schemas.knowledge import *
from app.schemas.scholarship import *
