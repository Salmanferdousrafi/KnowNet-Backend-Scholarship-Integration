"""
Scholarship / Internship model with embeddings and metadata.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ARRAY, Float, Numeric
from sqlalchemy.sql import func
from app.db.session import Base

class Scholarship(Base):
    __tablename__ = "scholarships"

    id = Column(Integer, primary_key=True, index=True)

    title = Column(String(500), nullable=False)
    provider = Column(String(255), nullable=True)
    source_url = Column(String(2048), nullable=False, unique=True)
    deadline = Column(DateTime(timezone=True), nullable=True)
    amount = Column(String(255), nullable=True)  # e.g., "$5,000", "Full tuition"
    eligibility_raw = Column(Text, nullable=True)

    # Structured metadata for filtering
    field_tags = Column(ARRAY(String), nullable=True)  # e.g., ["computer_science", "medicine"]
    country_scope = Column(ARRAY(String), nullable=True)  # e.g., ["US", "global"]
    education_levels = Column(ARRAY(String), nullable=True)  # e.g., ["bachelor", "master"]

    # Semantic embedding for AI matching
    embedding = Column(ARRAY(Float), nullable=True)

    is_active = Column(Boolean, default=True, nullable=False)
    last_verified_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    # Source tracking
    source_feed = Column(String(500), nullable=True)
    external_id = Column(String(255), nullable=True, index=True)
