"""
User model with extended profile fields for scholarship matching.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ARRAY, Float
from sqlalchemy.sql import func
from app.db.session import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=True)

    # Profile fields for scholarship matching
    field_of_study = Column(String(255), nullable=True)
    country = Column(String(100), nullable=True)
    education_level = Column(String(50), nullable=True)  # e.g., bachelor, master, phd
    bio = Column(Text, nullable=True)
    bio_embedding = Column(ARRAY(Float), nullable=True)  # Claude embedding vector

    is_active = Column(Boolean, default=True, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
