"""
Knowledge entry model with semantic embedding for AI search.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, ARRAY, Float
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.db.session import Base

class Knowledge(Base):
    __tablename__ = "knowledge"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)

    title = Column(String(500), nullable=False)
    content = Column(Text, nullable=False)
    source_url = Column(String(2048), nullable=True)
    tags = Column(ARRAY(String), nullable=True)

    # Semantic search embedding
    embedding = Column(ARRAY(Float), nullable=True)

    is_public = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    owner = relationship("User", backref="knowledge_entries")
    project = relationship("Project", backref="knowledge_entries")
