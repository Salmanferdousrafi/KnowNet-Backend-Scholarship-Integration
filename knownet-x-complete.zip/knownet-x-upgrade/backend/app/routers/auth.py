"""
Auth router: register, login, refresh, logout.
Rate limited via slowapi.
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.deps import get_db, limiter
from app.core.config import get_settings
from app.schemas.auth import TokenPair, RefreshRequest, RegisterRequest
from app.schemas.user import UserInDB
from app.services.auth_service import (
    authenticate_user,
    issue_token_pair,
    refresh_access_token,
    revoke_refresh_token,
)
from app.services.user_service import create_user, get_user_by_email

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=UserInDB, status_code=status.HTTP_201_CREATED)
@limiter.limit(get_settings().rate_limit_register)
async def register(request: Request, register_in: RegisterRequest, db: Session = Depends(get_db)):
    """Register a new user. Rate limited to 3/minute per IP."""
    existing = get_user_by_email(db, register_in.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user = create_user(db, register_in)
    return user

@router.post("/login", response_model=TokenPair)
@limiter.limit(get_settings().rate_limit_login)
async def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Login with email/password. Rate limited to 5/minute per IP. Returns JWT access + refresh tokens."""
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    access_token, refresh_token, expires_in = issue_token_pair(db, user)
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": expires_in,
    }

@router.post("/refresh", response_model=TokenPair)
async def refresh_token(refresh_in: RefreshRequest, db: Session = Depends(get_db)):
    """Rotate refresh token and issue new access + refresh pair."""
    access_token, new_refresh, expires_in = refresh_access_token(db, refresh_in.refresh_token)
    return {
        "access_token": access_token,
        "refresh_token": new_refresh,
        "token_type": "bearer",
        "expires_in": expires_in,
    }

@router.post("/logout", status_code=status.HTTP_200_OK)
async def logout(refresh_in: RefreshRequest, db: Session = Depends(get_db)):
    """Logout: revoke the refresh token server-side."""
    revoked = revoke_refresh_token(db, refresh_in.refresh_token)
    if not revoked:
        raise HTTPException(status_code=400, detail="Invalid or already revoked token")
    return {"detail": "Successfully logged out"}
