"""
Knowledge router with semantic search and strict ownership.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.deps import get_db, get_current_active_user
from app.schemas.user import UserInDB
from app.schemas.knowledge import KnowledgeCreate, KnowledgeUpdate, KnowledgeOut, KnowledgeSearchQuery
from app.services.knowledge_service import (
    get_knowledge_by_id,
    list_user_knowledge,
    create_knowledge,
    update_knowledge,
    delete_knowledge,
    verify_knowledge_owner,
    verify_knowledge_owner_write,
    semantic_search_knowledge,
)

router = APIRouter(prefix="/knowledge", tags=["knowledge"])

@router.get("", response_model=List[KnowledgeOut])
async def list_knowledge(
    project_id: int = None,
    include_public: bool = False,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    return list_user_knowledge(db, current_user.id, project_id=project_id, include_public=include_public)

@router.post("", response_model=KnowledgeOut, status_code=status.HTTP_201_CREATED)
async def create_knowledge_entry(
    knowledge_in: KnowledgeCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    return create_knowledge(db, current_user.id, knowledge_in)

@router.get("/{knowledge_id}", response_model=KnowledgeOut)
async def get_knowledge(
    knowledge_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    entry = get_knowledge_by_id(db, knowledge_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Knowledge entry not found")
    verify_knowledge_owner(entry, current_user.id)
    return entry

@router.patch("/{knowledge_id}", response_model=KnowledgeOut)
async def update_knowledge_endpoint(
    knowledge_id: int,
    knowledge_in: KnowledgeUpdate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    entry = get_knowledge_by_id(db, knowledge_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Knowledge entry not found")
    verify_knowledge_owner_write(entry, current_user.id)
    return update_knowledge(db, entry, knowledge_in)

@router.delete("/{knowledge_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_knowledge_endpoint(
    knowledge_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    entry = get_knowledge_by_id(db, knowledge_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Knowledge entry not found")
    verify_knowledge_owner_write(entry, current_user.id)
    delete_knowledge(db, entry)
    return None

@router.post("/search", response_model=List[KnowledgeOut])
async def search_knowledge(
    search_query: KnowledgeSearchQuery,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_active_user),
):
    """Semantic search over knowledge entries using Claude embeddings + cosine similarity."""
    return semantic_search_knowledge(db, current_user.id, search_query)
