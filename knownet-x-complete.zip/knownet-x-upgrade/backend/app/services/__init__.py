from app.services.user_service import *
from app.services.auth_service import *
from app.services.project_service import *
from app.services.knowledge_service import *
from app.services.scholarship_service import *
from app.services.ai_service import *
